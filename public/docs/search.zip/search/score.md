To turn off document relevancy scoring in search results, set **score** to none.

To turn on document relevancy scoring in search results, remove the **score** property.

→ [Search Request Json Documentation](https://docs.couchbase.com/server/current/search/search-request-params.html)