Enter an IP address range or single IP address, in IPv4 or IPv6 CIDR notation.

The Search Service returns documents with IP addresses that fall inside the specified range or match the specified IP address.

→ [IP Address Range Query Documentation](https://docs.couchbase.com/server/current/search/search-request-params.html#ip-address-range-queries)