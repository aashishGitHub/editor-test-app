Set the total number of results to return for a single page of search results.

If you provide both the **size** and **limit** properties, the Search Service uses the **size** value.

→ [Search Request Json Documentation](https://docs.couchbase.com/server/current/search/search-request-params.html)