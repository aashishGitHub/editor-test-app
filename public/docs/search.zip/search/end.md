Set the end date of the date range that you want to search for.

You can specify only an **end** value or only a **start** value on your date range.

By default, **end** is exclusive to the range.

→ [Date Range Query Documentation](https://docs.couchbase.com/server/current/search/search-request-params.html#date-range-queries)