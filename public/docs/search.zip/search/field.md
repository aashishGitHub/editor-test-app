Specify a specific field name, using dot notation, where the Search Service should search for a match to your search query.

→ [Additional Query Object Documentation](https://docs.couchbase.com/server/current/search/search-request-params.html#additional-query-properties)