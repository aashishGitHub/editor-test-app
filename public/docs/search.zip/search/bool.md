Use the **bool** property to query a field that contains a boolean value.

Use the field property and set the **bool** property to true or false to run a search.

The Search Service does not use any analyzers on the contents of your query.

→ [Non-Analytics Query Documentation]("https://docs.couchbase.com/server/current/search/search-request-params.html#non-analytic-queries")