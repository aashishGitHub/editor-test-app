Set the maximum value of the range that you want to search for.

You can specify only a **min** value or only a **max** value on your range.

By default, **max** is exclusive to the range.

→ [Numeric Range Query Documentation](https://docs.couchbase.com/server/current/search/search-request-params.html#numeric-range-queries)