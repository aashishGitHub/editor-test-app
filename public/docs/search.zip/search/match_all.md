Use the **match_all** object as the only property in your **query** object to return all documents from the Search index in search results.

→ [Special Queries Documentation](https://docs.couchbase.com/server/current/search/search-request-params.html#special-queries)