Contains the **shape** property and **relation** property.

Defines the GeoJSON shape and how the Search Service should find a match in documents.