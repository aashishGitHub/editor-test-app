Use the **query** object to set the specific details of your Search query.

Use the properties in the **query** object to control search result rankings, add multiple subqueries, and more.

→ [Query Object Documentation](https://docs.couchbase.com/server/current/search/search-request-params.html#query-object)