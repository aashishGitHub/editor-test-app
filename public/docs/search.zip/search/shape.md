Contains the **type** property and **coordinates** property.

Defines the specific GeoJSON shape to use in the query.