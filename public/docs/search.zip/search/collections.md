Contains an array of strings that specify the collections where you want to run the query.

→ [Search Request Json Documentation](https://docs.couchbase.com/server/current/search/search-request-params.html)