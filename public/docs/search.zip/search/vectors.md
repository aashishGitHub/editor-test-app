An object that contains a **{search-index-name}** object for each Search index in the query.

→ [Vectors Object Documentation](https://docs.couchbase.com/server/current/search/search-request-params.html#vectors)