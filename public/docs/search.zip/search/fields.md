An array of strings to specify each indexed field you want to return in search results.

You must add a field and its contents to a Search index to view it in search results or add it to the **fields** array.

→ [Search Request Json Documentation](https://docs.couchbase.com/server/current/search/search-request-params.html)