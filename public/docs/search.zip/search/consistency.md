Use the **consistency** object to control the consistency behavior for a Search index

It contains a **vectors** object, the **level** and **results** properties.

→ [Consistency Object Documentation](https://docs.couchbase.com/server/current/search/search-request-params.html#consistency)