To create an explanation for a search result's score in search results, set **explain** to true.

To turn off explanations for search result scoring, set **explain** to false.

→ [Search Request Json Documentation](https://docs.couchbase.com/server/current/search/search-request-params.html)