Enter the total number of results that you want to return from your Vector Search query.

The Search Service returns the **k** closest vectors to the vector given in vector.

**NOTE:** The **size** or **limit** property overrides any value set in **k**.

→ [Knn Object Documentation](https://docs.couchbase.com/server/current/search/search-request-params.html#knn-object)