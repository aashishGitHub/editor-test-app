Set the data type of the field specified in field:

→ **string**: The field contains a string.

→ **date**: The field contains date/time data.

→ **number**: The field contains a number or geographic data, like a latitude or longitude value.