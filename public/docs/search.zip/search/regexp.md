Use the **regexp** property to run a regular expression query.

Set the property to a regular expression to return matches for that regular expression in search results.

If you use the **regexp** property, the Search Service does not use any analyzers on the contents of your query text.

→ [Non-Analytics Query Documentation](https://docs.couchbase.com/server/current/search/search-request-params.html#non-analytic-queries)